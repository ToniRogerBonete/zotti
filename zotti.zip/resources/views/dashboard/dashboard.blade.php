@extends('layouts.app')

@section('content')
    <main>
        <dashboard>
            <div class="container-fluid">
                Carregando...
            </div>
        </dashboard>
    </main>
@endsection

@section('scripts')
    <script src="/js/dashboard.js"></script>
@endsection