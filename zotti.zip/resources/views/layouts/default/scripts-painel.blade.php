    <script src="/js/app.js"></script>
    {{ $slot }}