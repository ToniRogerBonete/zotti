    <script src="/js/bootstrap.js"></script>
    {{ $slot }}