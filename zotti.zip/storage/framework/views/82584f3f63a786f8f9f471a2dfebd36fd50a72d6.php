    <script src="/js/bootstrap.js"></script>
    <?php echo e($slot); ?>