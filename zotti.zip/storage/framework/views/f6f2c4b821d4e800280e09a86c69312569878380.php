    <script src="/js/app.js"></script>
    <?php echo e($slot); ?>