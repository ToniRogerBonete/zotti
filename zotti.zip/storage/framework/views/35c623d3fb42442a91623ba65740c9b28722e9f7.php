<div class="container-fluid pr-0 pl-0">
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
        <img src="<?php echo e(asset('brand/logo.jpg')); ?>" width="50" alt="">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <!-- Left Side Of Navbar -->
        <ul class="navbar-nav mr-auto">

        </ul>

        <!-- Right Side Of Navbar -->
        <ul class="navbar-nav ml-auto">
            <!-- Authentication Links -->
            <?php if(auth()->guard()->guest()): ?>
                
                
            <?php else: ?>
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <i class="fas fa-arrow-alt-circle-down"></i> Cadastros <span class="caret"></span>
                    </a>

                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('produto-view')): ?>
                        <a href="/painel/produtos" class="dropdown-item">
                            Cadastrar produtos
                        </a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lista-view')): ?>
                        <a href="/painel/listas" class="dropdown-item">
                            Cadastrar lista
                        </a>
                        <?php endif; ?>
                    </div>
                </li>
                <?php if(Gate::check('usuario-view') || Gate::check('papel-view')): ?>
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <i class="fas fa-cog"></i> Configurações <span class="caret"></span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario-view')): ?>
                        <a href="/painel/usuarios" class="dropdown-item">
                            Usuários
                        </a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('papel-view')): ?>
                            <a href="/painel/papeis" class="dropdown-item">
                                Papéis
                            </a>
                        <?php endif; ?>
                    </div>
                </li>
                <?php endif; ?>

                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <i class="fas fa-user"></i> <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('perfil-view')): ?>
                        <a class="dropdown-item" href="">
                            Perfil
                        </a>
                        <?php endif; ?>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            Sair
                        </a>
                    </div>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</div>
